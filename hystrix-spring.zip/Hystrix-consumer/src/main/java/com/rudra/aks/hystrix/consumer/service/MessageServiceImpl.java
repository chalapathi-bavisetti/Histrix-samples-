package com.rudra.aks.hystrix.consumer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.rudra.aks.hystrix.consumer.MessageReceiver;

@Service
public class MessageServiceImpl implements MessageService {

	private static Logger logger = LoggerFactory.getLogger(MessageReceiver.class);
	
	//@HystrixCommand(/*commandKey="customkey", */fallbackMethod="failedCall", ignoreExceptions = RuntimeException.class)
	@HystrixCommand(fallbackMethod = "failedCall", commandProperties={@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "5000")})
	public String showMessage(String username) {
		if ("demo".equals(username.trim().toLowerCase()))
			throw new RuntimeException("dummy name passed");
		//for checking instance execution time
		/*try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted : " + e);
		}*/
		String result = new RestTemplate().getForObject("http://localhost:8088/get/"+username, String.class);
		return result;
	}

	/**
	 * This will be invoked by hystrix circuit breaker if call failed to annotated method
	 * 
	 * @param username
	 * @return default message
	 */
	public String failedCall(String username, Throwable t) {
		logger.error("Fall Back called for exception: " + t.getMessage());
		return "Hello " + "user !";
	}
}
