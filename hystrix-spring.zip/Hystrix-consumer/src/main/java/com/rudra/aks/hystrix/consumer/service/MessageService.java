package com.rudra.aks.hystrix.consumer.service;

public interface MessageService {

	String showMessage(String name);
}
