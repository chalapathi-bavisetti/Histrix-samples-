package com.rudra.aks.hystrix.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.rudra.aks.hystrix.consumer.service.MessageService;

@RestController
public class MessageReceiver {

	private static Logger logger = LoggerFactory.getLogger(MessageReceiver.class);
	
	@Autowired
	MessageService	msgService;
	
	/***
	 * this method call will consume hystrix rest controller with username
	 * using msgService implementation which is having fault tolerance facility.
	 * 
	 * @param username
	 * @return
	 */
	@GetMapping("/show/{username}")
	public String	getMessage(@PathVariable("username") String username) {
		logger.info("Calling message with hystrix support : " + username);
		return msgService.showMessage(username);
	}
	
}
